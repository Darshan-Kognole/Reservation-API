import React from 'react'

const UserNavbar = () => {
  return (
    <div>UserNavbar</div>
  )
}

export default UserNavbar