import React from 'react'

const PageNotFound = () => {
  return (
    <div>
      <img src="https://static-00.iconduck.com/assets.00/404-page-not-found-illustration-2048x998-yjzeuy4v.png" alt="" />
    </div>
  )
}

export default PageNotFound