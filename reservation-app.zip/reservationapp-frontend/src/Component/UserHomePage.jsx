import React from 'react'
import UserNavbar from './UserNavbar'

const UserHomePage = () => {
  return (
    <div>
        <UserNavbar/>
    </div>
  )
}

export default UserHomePage