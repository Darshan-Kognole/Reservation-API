package org.jsp.reservationapi.util;

public enum AccountStatus {
	ACTIVATE,IN_ACTIVE,BLOCKED;
}
